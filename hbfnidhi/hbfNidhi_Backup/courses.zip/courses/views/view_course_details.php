<?php $this->load->view("top_application");?>
<section class="maincourse">
<div class="container">
    <div class="row">
        <div class="span12">
          <h1 class="header"><?php echo $res['course_name'];?></h1>
        </div>
    </div>
    <div class="row">
      <div class="span8">
              <!--weldiv  start-->
              <div class="weldiv">
                    <div class="dividerheading"></div>
                    <div class="body_text">
                      <div><?php echo $res['courses_description'];?></div>
                    </div>
                </div>                
      </div>
      <div class="span4">
           <!--services box start-->
          <div class="resistration">
          <h2>Request Callback</h2>
            <form class="form form-width">
             <input type="text" name="firstname" placeholder="Name">
             <input type="text" name="Mobile No." placeholder="Mobile No.">
             <input type="text" name="E-mail" placeholder="E-mail">
             <input type="text" name="Address" placeholder="Address">
             <textarea type="message" placeholder="Query"></textarea><br />
             <button><a href="">Submit</a></button>
            </form>
          </div>
      </div>
    </div>
  </div>
</section>
<?php $this->load->view("bottom_application");?>