<?php $this->load->view("top_application");?>
<section class="wrap-2 content1">
  <div class="container">
    <div class="row">
     <div class="span12">
     <h1 class="header"><?php echo $heading_title;?></h1>
    </div>
  </div>
<div class="slideshow-container">

<div class="row">
   <?php
    if(is_array($res) && !empty($res))
    {
       $ix=0;         
  
           foreach($res as $val)
       {
          $link_url=base_url()."courses/detail/".$val['courses_id'];
          $availableqty = ( $val['quantity'] - $val['used_quantity'] );         
        $availableqty = ($availableqty < 0 )  ? 0 :  $availableqty; 
   ?>

<div class="span3">
      <div class="news2">
       <img src="<?php echo get_image('courses',$val['media'],'500','500','R'); ?>" style="height: 125px;" alt="<?php echo $val['course_name'];?>" alt="">
    </div>
       <div class="bank bank1">
         <h2><?php echo character_limiter(strip_tags($val['course_name']),10);?></h2>
       <p><a href="<?php echo $link_url;?>">Classroom Courses</a></p>
       <p><a href="<?php echo $link_url;?>">Online Test Series</a></p>
       <p><a href="<?php echo $link_url;?>">Study Materials</a></p>
       <span class="bank-pa"><button><a href="<?php echo $link_url;?>">View All</a></button></span>
       </div>
    </div>
    <?php
      }
?>
<div class="span12">
     <div class="pagination">
          <p> <?php echo $page_links; ?></p>
           
     </div>
    </div>



    <?php }else
    {
      echo '<strong>No Records Here.</strong>';
    }
  ?>

    </div>
    
   
   </div>
   </div>
          <!-- add  more items here -->
          <!-- Example item start:  -->
          <!--  Example item end -->
   <!-- Left and right controls -->
  
</section>
<?php $this->load->view("bottom_application");?>