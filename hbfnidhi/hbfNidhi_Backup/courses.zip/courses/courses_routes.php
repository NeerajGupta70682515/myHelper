<?php
//$route['courses/detail/(:num)']    = 'courses/detail/$1';
//$route['courses/(:any)']           = 'courses/index/$1';
