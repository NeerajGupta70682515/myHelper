<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Course_model extends MY_Model
 {

		 
	 public function get_courses($limit='10',$offset='0',$param=array())
	 {
		
		$category_id		=   @$param['category_id'];
		$status			    =   @$param['status'];	
		$courseid			=   @$param['courseid'];
		$orderby			=	@$param['orderby'];	
		$where			    =	@$param['where'];	
		$keyword			=   trim($this->input->get_post('keyword',TRUE));						
		$keyword			=   $this->db->escape_str($keyword);
		
		
		
		if($category_id!='')
		{
			$this->db->where("wlp.category_id ","$category_id");
		}
		
		if($courseid!='')
		{
			$this->db->where("wlp.courses_id  ","$courseid");
		}
		
		if($status!='')
		{
			$this->db->where("wlp.status","$status");
		}
		
		if($where!='')
		{
			$this->db->where($where);
			
		}
		if($keyword!='')
		{
			$this->db->where("(wlp.course_name LIKE '%".$keyword."%' OR wlp.course_code LIKE '%".$keyword."%' )");
		}
		
		if($orderby!='')
		{		
			$this->db->order_by($orderby);
			
		}
		else
		{
			$this->db->order_by('wlp.courses_id ','desc');
		}
		
	    $this->db->group_by("wlp.courses_id"); 	
		$this->db->limit($limit,$offset);
		$this->db->select('SQL_CALC_FOUND_ROWS wlp.*,wlpm.media,wlpm.media_type,wlpm.is_default',FALSE);
		$this->db->from('tbl_courses as wlp');
		$this->db->where('wlp.status !=','2');
		$this->db->join('tbl_courses_media AS wlpm','wlp.courses_id=wlpm.courses_id','left');
		$q=$this->db->get();
		//echo_sql();
		$result = $q->result_array();	
		$result = ($limit=='1') ? @$result[0]: $result;	
		return $result;
				
	}
		  
	public function get_course_media($limit='4',$offset='0',$param=array())
    {		  
		
		 $default			    =   @$param['default'];	
		 $courseid			    =   @$param['courseid'];
		 $media_type			=   @$param['media_type'];
		 		
		 if( is_array($param) && !empty($param) )
		 {			
			$this->db->select('SQL_CALC_FOUND_ROWS *',FALSE);
			$this->db->limit($limit,$offset);
			$this->db->from('tbl_courses_media');
			$this->db->where('courses_id',$courseid);	
			
			if($default!='')
			{
				$this->db->where('is_default',$default);	
			}
			if($media_type!='')
			{
				$this->db->where('media_type',$media_type);	
			}
							
			$q=$this->db->get();
			$result = $q->result_array();	
			$result = ($limit=='1') ? $result[0]: $result;	
			return $result;	
			
		 }				
		
	}
		
	public function related_courses_added($courseId,$limit='NULL',$start='NULL')
	{
		$res_data =  array();
		$condtion = ($courseId!='') ? "status ='1' AND course_id = '$courseId' ":"status ='1'";
		$fetch_config = array(
													'condition'=>$condtion,
													'order'=>"id DESC",
													'limit'=>$limit,
													'start'=>$start,							 
													'debug'=>FALSE,
													'return_type'=>"array"							  
												 );		
		$result = $this->findAll('tbl_courses_related',$fetch_config);
		if( is_array($result) && !empty($result) )
		{
			foreach ($result as $val )
			{ 
				$res_data[$val['id']] =$val['related_id'];
			}
		}
		return $res_data;		
	}
	
	
	
	public function get_related_courses($courseId)
	{
		$condtion = (!empty($courseId)) ? "status !='2'  AND courses_id NOT IN(".implode(",",$courseId). ")" :"status !='2'";
				
		$fetch_config = array(
													'condition'=>$condtion,
													'order'=>"courses_id DESC",
													'limit'=>'NULL',
													'start'=>'NULL',							 
													'debug'=>FALSE,
													'return_type'=>"array"							  
												 );		
		$result = $this->findAll('tbl_courses',$fetch_config);
		return $result;	
	}
	
	
	public function related_courses($courseId,$limit='NULL',$start='NULL')
	{
		$res_data =  array();
		$condtion = ($courseId!='') ? "status ='1' AND course_id = '$courseId' ":"status ='1'";
		$fetch_config = array(
													'condition'=>$condtion,
													'order'=>"id DESC",
													'limit'=>$limit,
													'start'=>$start,							 
													'debug'=>FALSE,
													'return_type'=>"array"							  
												 );		
		$result = $this->findAll('tbl_courses_related',$fetch_config);
		if( is_array($result) && !empty($result) )
		{
			foreach ($result as $val )
			{ 
			
				$res_data[$val['id']] = $this->get_courses(1,0, array('courseid'=>$val['related_id']));
				
				
			}
		}
		
		$res_data = array_filter($res_data);
		return $res_data;		
	}
	
	public function get_shipping_methods()
	{
		$condtion = "status =1";
		$fetch_config = array(
													'condition'=>$condtion,
													'order'=>"shipping_id DESC",							 					 
													'debug'=>FALSE,
													'return_type'=>"array"							  
													);		
		$result = $this->findAll('tbl_shipping',$fetch_config);
		return $result;	
	}
	 
	 
	 
	 /*---------Color Image-------------*/
	
	public function get_color_image($offset=FALSE,$per_page=FALSE)
	{
		$keyword = $this->db->escape_str(trim($this->input->get_post('keyword',TRUE)));		
		$condtion = ($keyword!='') ? "media_status !='2' AND courses_id='".$this->uri->segment(4)."' ":"media_status !='2' AND courses_id='".$this->uri->segment(4)."'";
		
		$fetch_config = array(
		'condition'=>$condtion,
		'order'=>"id DESC",
		'limit'=>$per_page,
		'start'=>$offset,							 
		'debug'=>FALSE,
		'return_type'=>"array"							  
		);		
		$result = $this->findAll('tbl_courses_media',$fetch_config);
		return $result;	
	}
	
	public function get_color_by_id($id){
		
		$id = applyFilter('NUMERIC_GT_ZERO',$id);
		
		if($id>0)
		{
			$condtion = "media_status !='2' AND id=$id";
			$fetch_config = array(
			'condition'=>$condtion,							 					 
			'debug'=>FALSE,
			'return_type'=>"object"							  
			);
			$result = $this->find('tbl_courses_media',$fetch_config);
			return $result;		
		}
	}
	
	public function change_media_status()
	{
	    $arr_ids = $_REQUEST['arr_ids'];
		
		if(is_array($arr_ids)){
		
			$str_ids = implode(',', $arr_ids);
			
			if($this->input->post('status_action')=='Activate')
			{
				$query = $this->db->query("UPDATE tbl_courses_media   
				                           SET media_status='1' 
										   WHERE id in ($str_ids)");
										   
				$this->session->set_userdata(array('msg_type'=>'success'));				
				$this->session->set_flashdata('success',lang('activate'));	 
			}
			
			if($this->input->post('status_action')=='Deactivate')
			{
				$query = $this->db->query("UPDATE tbl_courses_media  
				                           SET media_status='0' 
										   WHERE id in ($str_ids)");
										   
				$this->session->set_userdata(array('msg_type'=>'success'));				
				$this->session->set_flashdata('success',lang('deactivate'));	 
				
			}
			
			if($this->input->post('status_action')=='Delete')
			{
				$query = $this->db->query("DELETE FROM tbl_courses_media 
				                           WHERE id in ($str_ids)");
										   
				$this->session->set_userdata(array('msg_type'=>'success'));				
				$this->session->set_flashdata('success',lang('deleted'));	 
			}
		}
	}
	
	/*---------End Color Image-------------*/
	
	/*---------Manage course Stock -------------*/
	
	public function course_id_stock_list($course_id)
	{
		$query="SELECT * FROM tbl_course_stock WHERE course_id='".$course_id."'  ORDER BY course_size ASC";
		$db_query=$this->db->query($query);
		if($db_query->num_rows() > 0)
		{
			$res=$db_query->result_array();
			return $res;
		}
		else
		{
			return false;
		}
		
	}
	 
	/*---------End  course Stock -------------*/
	
	
	
	//---------------Bulk Upload File---------
	
	public function add_bulk_upload_courses($worksheet)
	{
		for($i=1;$i<count($worksheet);$i++)
		{
			$cat_id			=	(!isset($worksheet[$i][0])) ? '' : addslashes(trim($worksheet[$i][0]));
			$course_name	=	(!isset($worksheet[$i][1])) ? '' : addslashes(trim($worksheet[$i][1]));
			$course_code	=	(!isset($worksheet[$i][2])) ? '' : htmlentities(trim($worksheet[$i][2]));
			$price			=	(!isset($worksheet[$i][3])) ? '' : (float)addslashes(trim($worksheet[$i][3]));
			$discount_price	=	(!isset($worksheet[$i][4])) ? '' : (float)addslashes(trim($worksheet[$i][4]));
			$course_size	=	(!isset($worksheet[$i][5])) ? '' : htmlentities(trim($worksheet[$i][5]));
			$course_color	=	(!isset($worksheet[$i][6])) ? '' : htmlentities(trim($worksheet[$i][6]));
			$brand			=	(!isset($worksheet[$i][7])) ? '' : addslashes(trim($worksheet[$i][7]));
			$location		=	(!isset($worksheet[$i][8])) ? '' : htmlentities(trim($worksheet[$i][8]));
			$size_guide_desc=	(!isset($worksheet[$i][9])) ? '' : htmlentities(trim($worksheet[$i][9]));
			$is_feature		=	(!isset($worksheet[$i][10])) ? '' : addslashes(trim($worksheet[$i][10]));
			$top_selling	=	(!isset($worksheet[$i][11])) ? '' : addslashes(trim($worksheet[$i][11]));
			$set_recent		=	(!isset($worksheet[$i][12])) ? '' : addslashes(trim($worksheet[$i][12]));
			$description	=	(!isset($worksheet[$i][13])) ? '' : htmlentities(trim($worksheet[$i][13]));
			$feature_desc	=	(!isset($worksheet[$i][14])) ? '' : htmlentities(trim($worksheet[$i][14]));
			$status			=	(!isset($worksheet[$i][15])) ? '' : addslashes(trim($worksheet[$i][15]));
			
			/*$pic1			=	(!isset($worksheet[$i][16])) ? '' : htmlentities(trim($worksheet[$i][16]));
			$pic2			=	(!isset($worksheet[$i][17])) ? '' : htmlentities(trim($worksheet[$i][17]));
			$pic3			=	(!isset($worksheet[$i][18])) ? '' : htmlentities(trim($worksheet[$i][18]));
			$pic4			=	(!isset($worksheet[$i][19])) ? '' : htmlentities(trim($worksheet[$i][19]));
			$pic5			=	(!isset($worksheet[$i][20])) ? '' : htmlentities(trim($worksheet[$i][20]));
			$pic6			=	(!isset($worksheet[$i][21])) ? '' : htmlentities(trim($worksheet[$i][21]));*/
			
			$dbfld=array();
			$categoryposted	=	$cat_id;
			
			$all_categories=getCategoryHierarchy($categoryposted);
			$categoryLinks=substr($all_categories,0,-1);
				
			$parentcategory=getfinallink($categoryposted);
			$topcat_res=$this->db->query("Select cat_id from tbl_category where cat_id IN(".$parentcategory.") and cat_status ='0'")->num_rows();
			$cat_status=$topcat_res > 0 ? '0' : '1';
			
			$data = array(
							'cat_id'			=>	$parentcategory,
							'cat_links'			=>	$categoryLinks,
							'course_name'		=>	$course_name,
							'course_code'		=>	$course_code,
							'brand'				=>	$brand,
							'course_size'		=>	$course_size,
							'course_color'		=>	$course_color,
							'location'			=>	$location,
							'size_guide_desc'	=>	$size_guide_desc,
							'description'		=>	$description,
							'feature_desc'		=>	$feature_desc,
							'is_feature'		=>	$is_feature,
							'top_selling'		=>	$top_selling,
							'set_recent'		=>	$set_recent,
							'recive_date' 		=>  date('Y-m-d h:i:s'),
							'cat_status'		=>	$cat_status,
							'status' 			=>  $status,
							'course_type' 		=>  'P',
							'xls_type' 			=>  'Y',
							
						 );
			$courseId =  $this->safe_insert('tbl_courses',$data,FALSE);
			
			
			$course_price     	= $price;
			$discount_price     = $discount_price;	
		
			$data1 = array(
							'pro_id'		=>	$courseId,
							'price'			=>	$course_price,
							'discount_price'=>	$discount_price,
						);
			$this->safe_insert('tbl_course_info',$data1,FALSE);
		}
		return true;
	}
	//--------------End Bulk Upload File-----
	  
}