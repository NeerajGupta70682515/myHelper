<?php $this->load->view("top_application");?>
<section class="maincourse">
<div class="container">
    <div class="row">
        <div class="span12">
          <h1 class="header"><?php echo $res['admission_title'];?></h1>
        </div>
    </div>
    <div class="row">
      <div class="span9">
              <!--weldiv  start-->
              <div class="weldiv">
                    <div class="dividerheading"></div>
                    <div class="body_text">
                      <div><?php echo $res['admission_description'];?></div>
                    </div>
                </div>                
      </div>
      <div class="span3">
          <!--services box start-->
        
          <?php echo $this->load->view('pages/callback'); ?>
                          
      </div>
    </div>
  </div>
</section>

<?php $this->load->view("bottom_application");?>