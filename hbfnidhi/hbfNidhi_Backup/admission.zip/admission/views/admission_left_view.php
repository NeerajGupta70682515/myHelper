<?php
$cat_limit = 0;
$this->load->model(array('admission/admission_model'));
$condtion_array = array(
'field' =>"*,( SELECT COUNT(id) FROM tbl_admission ",
		'condition'=>" AND status='1' ",
'condition'=>"AND status='1' ",
'limit'=>$cat_limit,
'offset'=>0,
'debug'=>FALSE
);	
$cat_res            = $this->admission_model->getadmission($condtion_array);
$total_cat_found	=  $this->admission_model->total_rec_found;	

?>
<!--<div class="navbar-collapse collapse clearfix">-->
   
   <?php
        if( is_array($cat_res) && !empty($cat_res))
        {
			$i=0;
			foreach($cat_res as $v)
			{
				
			   		
				   $link_url = base_url()."admission/details/".$v['admission_id'];	
				
        
        ?>
        
  <li><a href="<?php echo $link_url;?>" title="<?php echo $v['admission_title'];?>" ><?php echo character_limiter(strip_tags($v['admission_title']),15);?></a></li>
  
           
   <?php
    $i++;
	}
}

?>
 <!-- </div>-->