<?php $this->load->view('project_footer'); ?> 
        <script src="<?php echo theme_url();?>js/jquery-2.2.0.js"></script>
		<script src="<?php echo theme_url();?>js/smooth-scroll.js"></script>
		<script src="<?php echo theme_url();?>js/bootstrap.min.js"></script>
		<script src="<?php echo theme_url();?>js/counter.js"></script>
		<script src="<?php echo theme_url();?>js/common.js"></script>
		<script src="<?php echo theme_url();?>js/scripts.js"></script>
		<script src="<?php echo theme_url();?>js/hero-slider.js"></script>
		
		
		
		
		
		
		
		<script src="<?php echo theme_url();?>vendor/select2/select2.min.js"></script>
		<script type="text/javascript">
			
		(function ($) {
			"use strict";
			$('.column100').on('mouseover',function(){
				var table1 = $(this).parent().parent().parent();
				var table2 = $(this).parent().parent();
				var verTable = $(table1).data('vertable')+"";
				var column = $(this).data('column') + ""; 

				$(table2).find("."+column).addClass('hov-column-'+ verTable);
				$(table1).find(".row100.head ."+column).addClass('hov-column-head-'+ verTable);
			});

			$('.column100').on('mouseout',function(){
				var table1 = $(this).parent().parent().parent();
				var table2 = $(this).parent().parent();
				var verTable = $(table1).data('vertable')+"";
				var column = $(this).data('column') + ""; 

				$(table2).find("."+column).removeClass('hov-column-'+ verTable);
				$(table1).find(".row100.head ."+column).removeClass('hov-column-head-'+ verTable);
			});
		    

})(jQuery);
		</script>

		
		<!-- DEMO -->
		<script type="text/javascript">
			// ===== Scroll to Top ==== 
			$(window).scroll(function() {
			    if ($(this).scrollTop() >= 50) {        // If page is scrolled more than 50px
			        $('#return-to-top').fadeIn(200);    // Fade in the arrow
			    } else {
			        $('#return-to-top').fadeOut(200);   // Else fade out the arrow
			    }
			});
			$('#return-to-top').click(function() {      // When arrow is clicked
			    $('body,html').animate({
			        scrollTop : 0                       // Scroll to top of body
			    }, 500);
			});
		</script>
		
		
		<!-- DEMO -->

		<script src="<?php echo theme_url();?>js/app.js"></script>
		
		
    </body>

</html>