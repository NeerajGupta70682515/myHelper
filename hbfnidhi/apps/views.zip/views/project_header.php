			<header id="header" class="h-one-h">
				<div class="container">
					<div class="header clearfix">
						
						<a href="<?php echo base_url(); ?>" class="logo"><img src="<?php echo theme_url();?>images/logo.png" alt=""></a>
						
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#primary-nav" aria-expanded="false">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						
						<div class="search-btn">
							<a href="javascript:void(0);" class="search-trigger"><i class="icon-icons185"></i></a>
						</div>
						
						<div class="search-container">
							<i class="fa fa-times header-search-close"></i>
							<div class="search-overlay"></div>
							<div class="search">
								<form>
									<label>Search:</label>
									<input type="text" placeholder="">
									<button><i class="fa fa-search"></i></button>
								</form>
							</div>
						</div>
						
						<div class="collapse navbar-collapse js-navbar-collapse main-nav navbar-collapse collapse" id="primary-nav">
						      <ul class="nav navbar-nav nav-pills">
						      	<li class="dropdown mega-dropdown">
						          <a href="about-us.html" class="dropdown-toggle" data-toggle="dropdown">Start A Business
						          	<span><i class="fa fa-angle-down" aria-hidden="true"></i></span></a>

						          <ul class="dropdown-menu mega-dropdown-menu row">
						            <li class="col-sm-3">
						              <ul>
						                <li class="dropdown-header">Business  Registration</li>
						                <?php   
										  $buz_reg = $this->pages_model->get_srvices(2);  
										  if(is_array($buz_reg) && !empty($buz_reg)){
										  foreach($buz_reg as $buzrg){
										  ?>
						                	<li><a href="<?php echo base_url(); ?>business-registration/<?php echo $buzrg['service_url']; ?>"><?php echo $buzrg['service_title']; ?></a></li>
						                <?php } } ?>
						                
						                
						                
						                <li class="divider"></li>
						                <li class="dropdown-header">Trademark &amp; Patents</li>
						               <?php   
										  $trade_reg = $this->pages_model->get_srvices(5);  
										  if(is_array($trade_reg) && !empty($trade_reg)){
										  foreach($trade_reg as $trzrg){
										  ?>
						                	<li><a href="<?php echo base_url(); ?>trademark-and-patents/<?php echo $trzrg['service_url']; ?>"><?php echo $trzrg['service_title']; ?></a></li>
						                <?php } } ?>
						                
						              </ul>
						            </li>
						            <li class="col-sm-3">
						              <ul>
						                <li class="dropdown-header">NGO Registration</li>
						                <?php   
										  $ngo_reg = $this->pages_model->get_srvices(3);  
										  if(is_array($ngo_reg) && !empty($ngo_reg)){
										  foreach($ngo_reg as $ngorg){
										  ?>
						                	<li><a href="<?php echo base_url(); ?>ngo-registration/<?php echo $ngorg['service_url']; ?>"><?php echo $ngorg['service_title']; ?></a></li>
						                <?php } } ?>
						                
						                <li class="divider"></li>
						                <li class="dropdown-header">General Agreements</li>
						                <?php   
										  $gen_reg = $this->pages_model->get_srvices(7);  
										  if(is_array($gen_reg) && !empty($gen_reg)){
										  foreach($gen_reg as $genrg){
										  ?>
						                	<li><a href="<?php echo base_url(); ?>general-agreements/<?php echo $genrg['service_url']; ?>"><?php echo $genrg['service_title']; ?></a></li>
						                <?php } } ?>
						              </ul>
						            </li>
						            <li class="col-sm-3">
						              <ul>
						                <li class="dropdown-header">Government Registrations</li>
						                 <?php   
										  $gov_reg = $this->pages_model->get_srvices(4);  
										  if(is_array($gov_reg) && !empty($gov_reg)){
										  foreach($gov_reg as $govrg){
										  ?>
						                	<li><a href="<?php echo base_url(); ?>government-registrations/<?php echo $govrg['service_url']; ?>"><?php echo $govrg['service_title']; ?></a></li>
						                <?php } } ?>
						              </ul>
						            </li>
						            <li class="col-sm-3">
						              <ul>
						                <li class="dropdown-header">Business Agreements</li>
						                <?php   
										  $bzagr_reg = $this->pages_model->get_srvices(6);  
										  if(is_array($bzagr_reg) && !empty($bzagr_reg)){
										  foreach($bzagr_reg as $bzagreg){
										  ?>
						                	<li><a href="<?php echo base_url(); ?>business-agreements/<?php echo $bzagreg['service_url']; ?>"><?php echo $bzagreg['service_title']; ?></a></li>
						                <?php } } ?>
						              </ul>
						            </li>
						          </ul>
						        </li>
						        
						        
						        <li class="dropdown mega-dropdown">
						          <a href="about-us.html" class="dropdown-toggle" data-toggle="dropdown">Manage a business &amp; Compliance    <span><i class="fa fa-angle-down" aria-hidden="true"></i></span></a>
						          <ul class="dropdown-menu mega-dropdown-menu row">
						            <li class="col-sm-4">
						              <ul>
						                <li class="dropdown-header">Annual Compliance for Business</li>
						                <?php   
										  $anl_comp_buz = $this->pages_model->get_srvices(10);  
										  if(is_array($anl_comp_buz) && !empty($anl_comp_buz)){
										  foreach($anl_comp_buz as $anlcompbuz){
										  ?>
						                	<li><a href="<?php echo base_url(); ?>annual-compliance-for-business/<?php echo $anlcompbuz['service_url']; ?>"><?php echo $anlcompbuz['service_title']; ?></a></li>
						                <?php } } ?>
						              </ul>
						            </li>
						            <li class="col-sm-4">
						              <ul>
						                <li class="dropdown-header">Change In Business</li>
						                <?php   
										  $cng_buz = $this->pages_model->get_srvices(11);  
										  if(is_array($cng_buz) && !empty($cng_buz)){
										  foreach($cng_buz as $cngbuz){
										  ?>
						                	<li><a href="<?php echo base_url(); ?>change-in-business/<?php echo $cngbuz['service_url']; ?>"><?php echo $cngbuz['service_title']; ?></a></li>
						                <?php } } ?>
						              </ul>
						            </li>
						            
						            <li class="col-sm-4">
						              <ul>
						                <li class="dropdown-header">Taxation &amp; Audit </li>
						                <?php   
										  $tax_adt = $this->pages_model->get_srvices(12);  
										  if(is_array($tax_adt) && !empty($tax_adt)){
										  foreach($tax_adt as $taxadt){
										  ?>
						                	<li><a href="<?php echo base_url(); ?>taxation-and-audit/<?php echo $taxadt['service_url']; ?>"><?php echo $taxadt['service_title']; ?></a></li>
						                <?php } } ?>
						              </ul>
						            </li>
						          </ul>
						        </li>
						        
						        <li class="dropdown mega-dropdown">
						          <a href="about-us.html" class="dropdown-toggle" data-toggle="dropdown"> Advisory    <span><i class="fa fa-angle-down" aria-hidden="true"></i></span></a>
						          <ul class="dropdown-menu mega-dropdown-menu row">
									<?php 
									 $adv_query = "SELECT * FROM tbl_categories WHERE status='1' and parent_id='13'";
									 $adv_res   = $this->db->query($adv_query);
									 $list_adv = $adv_res -> result_array();
													//  print_r($list_adv);
									 foreach($list_adv as $ladvr){
									 ?>
					            
						            <li class="col-sm-4">
						              <ul>
						                <li class="dropdown-header"><?php echo $ladvr['category_name']; ?></li>
						                <?php   
										  $anl_comp_buz = $this->pages_model->get_srvices($ladvr['category_id']);  
										  if(is_array($anl_comp_buz) && !empty($anl_comp_buz)){
										  foreach($anl_comp_buz as $anlcompbuz){
										  ?>
						                	<li><a href="<?php echo base_url().$ladvr['friendly_url']; ?>/<?php echo $anlcompbuz['service_url']; ?>"><?php echo $anlcompbuz['service_title']; ?></a></li>
						                <?php } } ?>
						              </ul>
						            </li>
						           
						           <?php } ?>
						           
						          </ul>
						        </li>
						        
						        
						        
						        <li class="dropdown mega-dropdown">
						          <a href="about-us.html" class="dropdown-toggle" data-toggle="dropdown">About Us
						          	<span style="padding-left:5px;"><i class="fa fa-angle-down" aria-hidden="true"></i></span>
						          </a>
						          <ul class="dropdown-menu mega-dropdown-menu row pull-right" style="width: 300px;">
						            <li class="col-sm-12">
						              <ul>
						                <li><a href="<?php echo base_url(); ?>about-us">About us</a></li>
						                <li><a href="<?php echo base_url();?>blog">Blogs</a></li>
						                <li><a href="<?php echo base_url();?>resources">Resources </a></li>
						                <li><a href="<?php echo base_url();?>partner-with-us">Partner with Us</a></li>
						                <li><a href="<?php echo base_url(); ?>contact-us">Contact Us</a></li>
						              </ul>
						            </li>
						          </ul>
						        </li>
						      </ul>
						</div>
					</div>
                </div>
            </header>