<footer id="footer">
				<div class="container">
					<div class="footer-top clearfix">
					
						<div class="height-50"></div>
							
							<div class="row">
								<div class="col-md-3">
									<div class="title-block">
			                            <h5 class="title">GET CONNECTED</h5>
			                        </div>
			                        <nav class="services-footer">
			                            <ul>
                                        	<li>
			                                    <a href="<?php echo base_url();?>">Home</a>
			                                </li>
			                                <li>
			                                    <a href="<?php echo base_url();?>about-us">About Us</a>
			                                </li>
			                                <li>
			                                    <a href="<?php echo base_url();?>blog">Blogs</a>
			                                </li>
                                             <li>
			                                    <a href="<?php echo base_url();?>careers">Careers</a>
			                                </li>
			                                <li>
			                                    <a href="<?php echo base_url();?>partner-with-us">Partner with Us</a>
			                                </li>
			                                <li>
			                                    <a href="<?php echo base_url();?>contact-us">Contact Us</a>
			                                </li>
			                               
			                            </ul>
			                        </nav>
								</div>
								<div class="col-md-3">
									<div class="title-block">
			                            <h5 class="title">SERVICE</h5>
			                        </div>
			                        <nav class="services-footer">
			                            <ul>
			                                <li>
			                                    <a href="<?php echo base_url(); ?>all-services">All Services</a>
			                                </li>
			                                <li>
			                                    <a href="#">Order Status</a>
			                                </li>
			                                <li>
			                                    <a href="<?php echo base_url(); ?>privacy-policy">Privacy policy</a>
			                                </li>
			                                <li>
			                                    <a href="<?php echo base_url(); ?>terms-and-conditions">Terms and conditions</a>
			                                </li>
			                                <li>
			                                    <a href="<?php echo base_url(); ?>refund-policy">Refund Policy</a>
			                                </li>
			                                <li>
			                                    <a href="#">Employee Login</a>
			                                </li>

			                            </ul>
			                        </nav>
								</div>
								<div class="col-md-3">
									<div class="title-block">
			                            <h5 class="title">POPULAR SERVICES</h5>
			                        </div>
			                        <nav class="services-footer">
			                            <ul>
			                                <li>
			                                    <a href="<?php echo base_url(); ?>business-registration/private-limited-company">Private Limited</a>
			                                </li>
                                            <li>
			                                    <a href="<?php echo base_url(); ?>ngo-registration/trust-ngo-registration">NGO Registration</a>
			                                </li>
			                                <li>
			                                    <a href="<?php echo base_url(); ?>">Nidhi Company Registration</a>
			                                </li>
			                                <li>
			                                    <a href="<?php echo base_url(); ?>">Credit Co-operative Society</a>
			                                </li>
			                                <li>
			                                    <a href="<?php echo base_url(); ?>">NBFC Registration</a>
			                                </li>
			                                
			                                <li>
			                                    <a href="<?php echo base_url(); ?>">Annual Compliance</a>
			                                </li>

			                            </ul>
			                        </nav>
								</div>
								<div class="col-md-3">
									<div class="title-block">
										<h5 class="title">Accepted Payment</h5>

										<div class="pb30">
				                            <a href="#">
				                                <img src="<?php echo theme_url(); ?>img/icon/3.png">
				                            </a>
				                            <a href="#">
				                                <img src="<?php echo theme_url(); ?>img/icon/4.png">
				                            </a>
				                             <a href="#">
				                                <img src="<?php echo theme_url(); ?>img/icon/2.png">
				                            </a>
				                            <a href="#">
				                                <img src="<?php echo theme_url(); ?>img/icon/5.png">
				                            </a>
				                            <a href="#">
				                                <img src="<?php echo theme_url(); ?>img/icon/1.png">
				                            </a>
				                        </div>

				                        <div class="title-block social-icon-1">
				                            <h5 class="title">Social Icon</h5>
				                        </div>
										
			                    <?php 
								$sel_social = "select * from tbl_social_profile Where social_id =1"; 
								$social_qry = $this->db->query($sel_social);
								$list_social = $social_qry->result_array();
								//print_r($list_social); 
								//$srv_phone = $list_admin[0]['phone'];	
								
								?>
				                        <div class="top-social bg-social social_iocn services-footer">
				                            <a target="_blank" href="<?php echo $list_social[0]['facebook']; ?>">
				                                <i class="fa fa-facebook"></i>
				                            </a>
				                            <a target="_blank" href="<?php echo $list_social[0]['twitter']; ?>">
				                                <i class="fa fa-twitter"></i>
				                            </a>
				                            <a target="_blank" href="<?php echo $list_social[0]['google']; ?>">
				                                <i class="fa fa-google-plus"></i>
				                            </a>
				                            <a target="_blank" href="<?php echo $list_social[0]['instagram']; ?>">
				                                <i class="fa fa-instagram"></i>
				                            </a>
				                            <div class="clearfix"></div>
				                        </div>
									</div>
								</div>
							</div>
					</div>
				</div>

				<div class="footer-bottom copy-right">
					<div class="container">
						<div class="row">
							<div class="col-md-12 col-sm-12 text-center"><p>Coyright © 2018 Megavisors.</p></div>
						</div>
					</div>
				</div>
			</footer>
			
							
			
			
			
		   <?php 
			$sel_admin = "select phone from tbl_admin Where admin_id =1"; 
			$admin_qry = $this->db->query($sel_admin);
			$list_admin = $admin_qry->result_array();
			?>
   	        <div class="modal-login">
   	        					
    				<span class="pull-left" style="padding-right:5px">
           		<i class="fa fa-phone" aria-hidden="true"></i>  +91 <?php echo $list_admin[0]['phone']?></span>
            		<div class="center pull-right"><button data-toggle="modal" data-target="#squarespaceModal" class="log-in">Log In</button></div>

            		<div class="center pull-right"><button data-toggle="modal" data-target="#ModalMessage" class="log-in"> Call Back
		            </button></div>
					
                	<div class="modal fade" id="ModalMessage" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
						<div class="modal-dialog">
                         <?php echo validation_message();?>
                        <?php //echo error_message();?>
                        <?php echo form_open_multipart("call-back",'class="form-horizontal"'); ?>
						
						   
						      <div class="modal-content">
						        <div class="modal-header">
						          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
						          <h4 class="text-center m-0"  id="myModalLabel">SCHEDULE A CALL BACK</h4>
						        </div>
						        <div class="modal-body">
						          <div class="control-group">
					            <input type="text"  name="name" placeholder="Name" maxlength="20" class="form-control" required="" value="<?php echo set_value('name');?>" />
						          </div>
						          <div class="control-group">
					            	<input type="email"  id="email" placeholder="E-mail Address" maxlength="40" required="" name="email" value="<?php echo set_value('email');?>" class="form-control">
						          </div>
						          <div class="control-group">
					            <input type="text"  name="mobile"	maxlength="10" placeholder="Mobile No" required="" class="form-control" value="<?php echo set_value('mobile');?>" >
						          </div>
						          <div class="control-group">
                                  	<input type="text"  name="city"	maxlength="20" placeholder="City" required="" class="form-control" value="<?php echo set_value('city');?>" >
						          </div>
						        </div>
						        <div class="modal-footer">
						          <div class="text-center">
						            <button type="submit" class="btn btn-primary" data-text="Get a free consultancy">Get a free consultancy</button>
						          </div>
						        </div>
						      </div>
						    </form>
						  </div>
					</div>
                
                
	            	
	            
	            
		            <div class="modal fade" id="squarespaceModal" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
					  <div class="modal-dialog">
						<div class="modal-content">
							<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
								<h3 class="modal-title" id="lineModalLabel">Login to your account</h3>
							</div>
							<div class="modal-body">
								<?php $ref=$this->input->get_post('ref');?>
								    <?php echo form_open('users/login');?>
                                    <?php echo validation_message();?>
      								<?php echo error_message(); ?>
					              <div class="form-group">
                                   <input type="text" name="user_name" id="user_name" class="form-control" placeholder="Enter email" value="<?php if(get_cookie('userName')!=""){ echo get_cookie('userName'); } ?>">
					              </div>
					              <div class="form-group">
                                 <input type="password" name="password" id="password" class="form-control" placeholder="Password" value="<?php if(get_cookie('pwd')!=""){ echo get_cookie('pwd'); } ?>" >

					              </div>
					              <span class="forgot-password">Forgot your password? <a href="<?php echo base_url(); ?>users/forgotten_password" class="forgot-password learn-more">Click here</a> to reset</span>
					              <!-- <a href="#" class="forgot-password learn-more text-center">Forgot password?</a> -->
					              	<input type="hidden" name="action" value="Add">
            						<input type="hidden" name="ref" value="<?php echo $ref;?>" />
                                  <button type="submit" class="btn btn-primary forgot-password-3 center-block" data-text="SIGN IN">SIGN IN</button>

					           <?php echo form_close();?>
							</div>
						</div>
					  </div>
					</div>
					
            	</div>
            	
            