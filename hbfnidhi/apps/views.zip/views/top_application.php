<!DOCTYPE html>
<html lang="en" class="no-js">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
	 <meta charset="utf-8">
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<?php 
		$meta_rec = getMeta();
	if( array_key_exists('dynamic_meta',$meta_rec) && @is_array($meta_array) && !empty($meta_array) )
		{
    if(  array_key_exists('meta_title',$meta_array) && $meta_array['meta_title']!='')
		{
			echo '<title>'.$meta_array['meta_title'].'</title>';
		}

		if( array_key_exists('meta_description',$meta_array) && $meta_array['meta_description']!='')
		{
			echo '<meta name="description" content="'.$meta_array['meta_description'].'" />';
		}

		if( array_key_exists('meta_keyword',$meta_array) && $meta_array['meta_keyword']!='')
		{
		   echo '<meta  name="keywords" content="'.$meta_array['meta_keyword'].'" />';
		}

		}
        else
		{	
		?>
		<title><?php echo $meta_rec['meta_title'];?> </title>
		<meta name="description" content="<?php echo $meta_rec['meta_description'];?>" />
		<meta  name="keywords" content="<?php echo $meta_rec['meta_keyword'];?>" />
		<?php
		}
		?>
        <meta name="author" content="">
        <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
        <meta name="format-detection" content="telephone=no">
        <link rel="icon" type="image/png" href="<?php echo theme_url();?>images/favicon.png">
        <link href='https://fonts.googleapis.com/css?family=Montserrat:400,700%7COpen+Sans:400,300,600,700' rel='stylesheet' type='text/css'>
	   <link rel="stylesheet" href="<?php echo theme_url();?>css/bootstrap.css">
	   <link rel="stylesheet" href="<?php echo theme_url();?>css/advisor.css">
	   <link rel="stylesheet" href="<?php echo theme_url();?>css/plugins.css">	
	   <link rel="stylesheet" id="color" href="<?php echo theme_url();?>css/color-default.css">
	   <link rel="stylesheet" href="<?php echo theme_url();?>css/hero-slider.css">
	   <link rel="stylesheet" href="<?php echo theme_url();?>css/responsive.css">
	   <link rel="stylesheet" type="text/css" href="<?php echo theme_url();?>css/custom.css">
	
 	<link rel="stylesheet" type="text/css" href="<?php echo theme_url();?>vendor/animate/animate.css">
	<link rel="stylesheet" type="text/css" href="<?php echo theme_url();?>vendor/select2/select2.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo theme_url();?>vendor/perfect-scrollbar/perfect-scrollbar.css">
	<link rel="stylesheet" type="text/css" href="<?php echo theme_url();?>css/util.css">
	<link rel="stylesheet" type="text/css" href="<?php echo theme_url();?>css/main.css">
	
	<script type='text/javascript' src='https://code.jquery.com/jquery-3.2.1.min.js'></script>
	<script src="<?php echo theme_url();?>js/modernizr.js"></script>
</head>
   
<script>
function jssign()
{
$(document).ready(function () {
$('#ModalMessage').modal('show');
});
//alert('hii');
//document.getElementById('signup').click();	
}
</script>

<body class="fixed-header">

<?php
  $this->load->view('project_header'); 
?>